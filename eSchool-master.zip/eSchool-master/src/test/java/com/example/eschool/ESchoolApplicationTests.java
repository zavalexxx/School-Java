package com.example.eschool;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ESchoolApplicationTests {

	@Test
	void contextLoads() {
	}

}
